<?php
$lang = array(
	'message' => 'Sorry, our site is currently down for maintenance. Please try again in a few minutes.',
);
?>
