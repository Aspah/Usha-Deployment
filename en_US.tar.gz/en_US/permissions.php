<?php
$lang = array(
	"reports_view" => "View Reports",
	"reports_edit" => "Create/Edit/Delete Reports",
	"reports_approve" => "Approve Reports",
	"reports_verify" => "Verify Reports",
	"reports_comments" => "Manage Report Comments",
	"reports_download" => "Download Reports",
	"reports_upload" => "Upload Reports",
	"messages" => "Manage Messages",
	"messages_reporters" => "Manage Message Reporters",
	"stats" => "View Stats",
	"settings" => "Modify Settings",
	"manage" => "Manage Panel",
	"users" => "Manage Users",
	"manage_roles" => "Manage Roles",
	"checkin" => "Can checkin",
	"checkin_admin" => "Manage checkins",
	"admin_ui" => "Access Admin UI",
	"member_ui" => "Access Members UI",
	"delete_all_reports" => "Delete all reports"
);
